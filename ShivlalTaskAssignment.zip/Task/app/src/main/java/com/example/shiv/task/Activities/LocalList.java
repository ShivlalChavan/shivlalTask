package com.example.shiv.task.Activities;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.shiv.task.Database.DBHelper;
import com.example.shiv.task.Model.Model;
import com.example.shiv.task.R;
import com.example.shiv.task.ViewBinder.LocalListAdapter;

import java.util.ArrayList;

public class LocalList extends AppCompatActivity {

    DBHelper helper;
    RecyclerView recyclerView;
    LocalListAdapter adapter;
    ArrayList<Model> list;
    Model model;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_list);

        helper=new DBHelper(this);



        Xmlinit();
        getData();




    }

    private void getData() {

        list=new ArrayList<>();



        Cursor c=helper.postdetail();

        if(c.getCount()!=0) {
            while (c.moveToNext()){

                String title=c.getString(1);
                String content=c.getString(2);

                try{

                    model=new Model();
                    model.setTitle(title);
                    model.setBody(content);
                    list.add(model);



                }catch (Exception e){
                    Log.e("Inexception", "Error " + e.toString());
                }

            }
            c.close();
            }

            adapter=new LocalListAdapter(this,list);
            recyclerView.setAdapter(adapter);



    }

    private void Xmlinit() {

        recyclerView=(RecyclerView)findViewById(R.id.local_recyclelist);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
    }
}
