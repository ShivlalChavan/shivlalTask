package com.example.shiv.task.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.shiv.task.Database.DBHelper;
import com.example.shiv.task.R;

public class LocalAddList extends AppCompatActivity implements View.OnClickListener {

    EditText titleEdt,contentEdt;
    Button Addbtn,viewBtn;
    private String Title="" ,Content="";
    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_add_list);

        XmlInit();
        dbHelper=new DBHelper(this);
        Addbtn.setOnClickListener(this);
        viewBtn.setOnClickListener(this);




    }

    private void XmlInit() {
        titleEdt=(EditText)findViewById(R.id.title_edt);
        contentEdt=(EditText)findViewById(R.id.content_edt);
        Addbtn=(Button)findViewById(R.id.btn_post);
        viewBtn=(Button)findViewById(R.id.view_post);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.btn_post:

                Title=titleEdt.getText().toString().trim();
                Content=contentEdt.getText().toString();

                if(Title.isEmpty()){

                    Toast.makeText(this, "Please enter title", Toast.LENGTH_SHORT).show();
                }else if(Content.isEmpty()){

                    Toast.makeText(this, "Please enter content", Toast.LENGTH_SHORT).show();
                }else
                {


                    dbHelper.add_post(Title, Content);

                    Toast.makeText(this, "Added Successfully..", Toast.LENGTH_SHORT).show();
                    titleEdt.setText("");
                    contentEdt.setText("");


                }


                break;


            case R.id.view_post:

                startActivity(new Intent(LocalAddList.this,LocalList.class));
                break;
        }

    }
}
