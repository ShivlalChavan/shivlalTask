package com.example.shiv.task;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.shiv.task.Activities.AddProducts;
import com.example.shiv.task.Activities.UpdatePosts;
import com.example.shiv.task.Model.Model;
import com.example.shiv.task.ViewBinder.PostListAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ViewGroup headerView;
    android.support.v7.widget.Toolbar toolbar;
    private ActionBarDrawerToggle actionBarDrawerToggle;

    private static final String ProgressConstant="Please wait..";


    private ProgressDialog mDailog;


    ApiInterface apiInterface;
    RecyclerView postListRecycler;
    PostListAdapter postListAdapter;
    List<Model> postList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDailog=new ProgressDialog(this);
        mDailog.setMessage(ProgressConstant);
        mDailog.setCancelable(false);
        postList=new ArrayList<>();





        initXml();
        getPostList();
        postListAdapter=new PostListAdapter(this,postList);
        postListRecycler.setAdapter(postListAdapter);


       // postListRecycler.setOnClickListener((View.OnClickListener) MainActivity.this);




    }

    public PostListAdapter getPostListAdapter() {
        return postListAdapter;
    }

    private void deletePostList() {

     /*postListAdapter.setOnItemclickListener(new PostListAdapter.ItemClickListener() {
         @Override
         public void onItemClick(View view, int position, Model model) {
             Log.d("got","deleteId"+postList.get(position).getId());
             Log.d("got","deleteId"+model.getId());

         }
     });*/


    }

    private void getPostList() {


        mDailog.show();



        apiInterface=ApiClient.getClient().create(ApiInterface.class);

        Call<List<Model>> apiCall=apiInterface.getPosts();
         apiCall.enqueue(new Callback<List<Model>>() {
             @Override
             public void onResponse(Call<List<Model>> call, Response<List<Model>> response) {

                 Log.d("response string ","ali"+response.toString()+response.body());

                 mDailog.dismiss();
                 postList.clear();
                 if(response.isSuccessful() && response.body()!=null) {
                     postList=response.body();
                     appendData(postList);
                 }else{
                     Toast.makeText(MainActivity.this, "No Data Availabe", Toast.LENGTH_SHORT).show();
                 }

             }

             @Override
             public void onFailure(Call<List<Model>> call, Throwable t) {

                 Log.e("MainActivity onFaliure ","Listresponse"+t.getMessage());


             }
         });


        //deletePostList();






    }

    private void appendData(final List<Model> postList) {



//        postListAdapter=new PostListAdapter(this,postList);
//        postListRecycler.setAdapter(postListAdapter);
        postListAdapter.setPostlist(postList);


        }





    @Override
    protected void onStart() {
        super.onStart();



    }




    private void initXml() {

        toolbar= (android.support.v7.widget.Toolbar) findViewById(R.id.action_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        navigationView=(NavigationView)findViewById(R.id.navigation_View);
        navigationView.getMenu().clear();
        navigationView.inflateMenu(R.menu.drawer_menu);
        navigationView.setItemIconTintList(null);

        headerView=(ViewGroup)getLayoutInflater().inflate(R.layout.header,null);
        navigationView.addHeaderView(headerView);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.isChecked()) menuItem.setChecked(false);
                else menuItem.setChecked(true);

                drawerLayout.closeDrawers();

                Menu menu=navigationView.getMenu();



                switch (menuItem.getItemId()){

                    case R.id.products:
                        startActivity(new Intent(MainActivity.this, AddProducts.class));

                        break;

                    case R.id.posts:
                        //startActivity(new Intent(MainActivity.this,UpdatePosts.class));

                        break;

                }


                return true;

            }
        });

        drawerLayout=findViewById(R.id.nav_drawer);
        actionBarDrawerToggle=new ActionBarDrawerToggle(MainActivity.this,drawerLayout,toolbar,R.string.openDrawer,R.string.closeDrawer){

            @Override
            public void onDrawerClosed(View drawerView) {
                // Code here will be triggered once the drawer closes as we dont want anything to happen so we leave this blank
                super.onDrawerClosed(drawerView);
                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                // Code here will be triggered once the drawer open as we dont want anything to happen so we leave this blank
                super.onDrawerOpened(drawerView);
                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }

        };

        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerVisible(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessay or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


        postListRecycler= (RecyclerView)findViewById(R.id.recyclelist);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        postListRecycler.setLayoutManager(linearLayoutManager);




    }





    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        // Handle your other action bar items...

        return super.onOptionsItemSelected(item);
    }





}
