package com.example.shiv.task.Activities;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shiv.task.ApiClient;
import com.example.shiv.task.ApiInterface;
import com.example.shiv.task.R;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdatePosts extends AppCompatActivity implements View.OnClickListener {


     EditText titleEdt,contentEdt;
     Button updateBtn;

    int id;
    String title,content;

    ApiInterface apiInterface;
    ProgressDialog mDailog;
    private static final String ProgressConstant="Updating wait..";






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_products);


        if(getIntent().hasExtra("Id") && getIntent().hasExtra("Title") && getIntent().hasExtra("Body")) {
            id = getIntent().getExtras().getInt("Id");
            title = getIntent().getExtras().getString("Title");
            //Log.d("while", "sending" + title);
            content = getIntent().getExtras().getString("Body");
        }


        mDailog=new ProgressDialog(this);
        mDailog.setMessage(ProgressConstant);
        mDailog.setCancelable(false);


        XmlInt();
        AppendData();

        updateBtn.setOnClickListener(this);







    }


    private void AppendData() {

        if(title!=null && !title.equals(" "))
        {
            titleEdt.setText(title);
        }
        if(content!=null && !content.equals(" "))
        {
            contentEdt.setText(content);
        }


    }

    private void XmlInt() {

        titleEdt=(EditText)findViewById(R.id.title_edt);
        contentEdt=(EditText)findViewById(R.id.content_edt);
        updateBtn=(Button)findViewById(R.id.btn_post);

        }


    @Override
    public void onClick(View view) {

        switch (view.getId()){

          case R.id.btn_post:

                title=titleEdt.getText().toString();
                content=contentEdt.getText().toString();
                content=content.replaceAll("\n","%2");
                content=content.replaceAll(" ","%20");

                 if(!title.isEmpty() && !content.isEmpty()){
                     updatePost(id,title,content);
                 }else {
                     Toast.makeText(this, "Enter fields to update", Toast.LENGTH_SHORT).show();
                 }



              break;

      }
    }


    private void updatePost(int id,String title, String content) {
        mDailog.show();


        apiInterface= ApiClient.getClient().create(ApiInterface.class);

        Call<ResponseBody> updatePost=apiInterface.editPost(id,title,content);
        updatePost.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                mDailog.dismiss();
                if(response.isSuccessful()&& response.body()!=null){
                    Log.i("in update ","message"+response.toString());

                    Toast.makeText(UpdatePosts.this, "Updated values", Toast.LENGTH_SHORT).show();
                    titleEdt.setText("");
                    contentEdt.setText("");
                }else {
                    Log.i("in update ","message"+response.toString());
                }


            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                Log.e("InUpdate","posts"+t.getMessage());

            }
        });
    }
}
