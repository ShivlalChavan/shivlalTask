package com.example.shiv.task.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.shiv.task.ViewBinder.PostListAdapter;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DBNAME="TaskDB";

    private static final String PostTable="PostListTable";

    private static final String Title="title";
    private static final String Content="content";



    public static final String Posttable="create table "+PostTable+"(id INTEGER PRIMARY KEY AUTOINCREMENT , title VARCHAR(255) , content VARCHAR(255))";



    public DBHelper(Context context) {

        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(Posttable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+PostTable);

    }



    public void add_post(String title,String content){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues value =new ContentValues();
        value.put(Title,title);
        value.put(Content,content);
        db.insertWithOnConflict(PostTable,null,value,SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }


    public Cursor postdetail(){

        SQLiteDatabase db=this.getReadableDatabase();

        Cursor c =db.rawQuery( "SELECT * FROM "+PostTable,null);
        return c;
    }

    public void deletelist(String title){

        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(PostTable, title+"='title'", null);
        db.close();
    }



}
