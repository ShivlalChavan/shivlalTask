package com.example.shiv.task.Activities;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.shiv.task.ApiClient;
import com.example.shiv.task.ApiInterface;
import com.example.shiv.task.R;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AddProducts extends AppCompatActivity implements View.OnClickListener{

    EditText titleEdt,contentEdt;
    Button addBtn;

    String Title="",Content="";
    ApiInterface apiInterface;

    ProgressDialog mProgress;
    private static final String ProgressConstant="Updating post...";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_products);

        mProgress=new ProgressDialog(this);
        mProgress.setMessage(ProgressConstant);

        Xmlint();
        addBtn.setOnClickListener(this);



    }


    private void Xmlint() {

        titleEdt=(EditText)findViewById(R.id.title_edt);
        contentEdt=(EditText)findViewById(R.id.content_edt);
        addBtn=(Button)findViewById(R.id.btn_post);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.btn_post:

                Title=titleEdt.getText().toString().trim();
                Content=contentEdt.getText().toString();

                 if(Title.isEmpty()){

                     Toast.makeText(this, "Please enter title", Toast.LENGTH_SHORT).show();
                  }else if(Content.isEmpty()){

                     Toast.makeText(this, "Please enter content", Toast.LENGTH_SHORT).show();
                 }else
                 {

                     postData(Title,Content);

                 }




                break;

        }

    }

    private void postData(String title, final String content) {
        mProgress.setCancelable(false);
        mProgress.show();

        apiInterface= ApiClient.getClient().create(ApiInterface.class);

        Call<ResponseBody> postdata=apiInterface.putPosts(title,content);

        postdata.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if(response.isSuccessful() && response.body()!=null){
                    Log.d("inresponse","updated"+response.toString());
                    mProgress.dismiss();
                    Toast.makeText(AddProducts.this,"Post Updated",Toast.LENGTH_SHORT).show();
                    titleEdt.setText("");
                    contentEdt.setText("");

                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                Log.e("AddProducts","error"+t.getMessage());



            }
        });


    }
}
