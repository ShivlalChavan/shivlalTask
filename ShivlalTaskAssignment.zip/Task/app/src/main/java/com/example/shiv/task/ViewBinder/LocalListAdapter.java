package com.example.shiv.task.ViewBinder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.shiv.task.Activities.LocalAddList;
import com.example.shiv.task.Activities.LocalList;
import com.example.shiv.task.Database.DBHelper;
import com.example.shiv.task.Model.Model;
import com.example.shiv.task.R;

import java.util.ArrayList;

public class LocalListAdapter extends RecyclerView.Adapter<LocalListAdapter.ViewHolder> {

    private Context context;
    public ArrayList<Model> list;
    DBHelper helper;



    public LocalListAdapter(Context mcontext,ArrayList<Model> list){


        this.context=mcontext;
        this.list=list;
    }







    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.post_list_item,viewGroup,false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        final Model model=list.get(i);

        viewHolder.titletxt.setText(model.getTitle());
        viewHolder.contenttxt.setText(model.getBody());

       /* viewHolder.deleteImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String title=  model.getTitle();
              helper=new DBHelper(context);
              helper.deletelist(title);



              notifyDataSetChanged();
            }
        });*/

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void removeItem(int position){
        list.remove(position);
        notifyItemRemoved(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView titletxt,contenttxt;
        ImageView editImg,deleteImg;


        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            titletxt=(TextView)itemView.findViewById(R.id.title_txt_content);
            contenttxt=(TextView)itemView.findViewById(R.id.contnt_txt_content);
            editImg =(ImageView)itemView.findViewById(R.id.edit_postImg);
            deleteImg=(ImageView)itemView.findViewById(R.id.delete_postImg);

            deleteImg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeItem(getAdapterPosition());
                    notifyDataSetChanged();
                }
            });

        }
    }


}
