package com.example.shiv.task;

import com.example.shiv.task.Model.Model;

import java.util.List;

import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {


    @GET("posts")
    Call<List<Model>> getPosts();


    @POST("posts")
    Call<ResponseBody> putPosts(@Query("title") String title,@Query("body") String content);


    @PUT("posts/{id}")
    Call<ResponseBody> editPost(@Path("id") int id , @Query("title") String title, @Query("body") String content);

    @DELETE("posts/{id}")
    Call<ResponseBody> deletePost(@Path("id")int id);



}
