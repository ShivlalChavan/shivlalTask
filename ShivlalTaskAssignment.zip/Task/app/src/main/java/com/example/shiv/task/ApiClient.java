package com.example.shiv.task;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Modifier;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    public static String BaseUrl="https://jsonplaceholder.typicode.com/";
    public static Retrofit retrofit;


   public static Retrofit getClient(){

       if(retrofit==null){

           retrofit=new Retrofit.Builder().baseUrl(BaseUrl).addConverterFactory(GsonConverterFactory.create()).build();
       }
       return retrofit;
   }


}
