package com.example.shiv.task.ViewBinder;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.telecom.Call;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shiv.task.Activities.UpdatePosts;
import com.example.shiv.task.ApiClient;
import com.example.shiv.task.ApiInterface;
import com.example.shiv.task.Model.Model;
import com.example.shiv.task.R;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Callback;
import retrofit2.Response;

public class PostListAdapter  extends RecyclerView.Adapter<PostListAdapter.ViewHolder>  {

    private Context mcontext;
    private List<Model> mlist;
   // private ItemClickListener itemClickListener;
    ApiInterface apiInterface;



    public PostListAdapter(Context context,List<Model> list){
        this.mcontext=context;
        this.mlist=list;


    }




    public void setPostlist(List<Model> list){
        mlist.clear();
        this.mlist=list;
        notifyDataSetChanged();


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.post_list_item,viewGroup,false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        final Model model=mlist.get(i);

        viewHolder.titletxt.setText(model.getTitle());
        viewHolder.contenttxt.setText(model.getBody());

        viewHolder.deleteImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int postlistId=model.getId();
                deleteItem(postlistId);
                Log.d("item","click"+model.getId());


            }
        });




       viewHolder.editImg.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               Intent intent=new Intent(mcontext, UpdatePosts.class);
               intent.putExtra("Id",model.getId());
               intent.putExtra("Title",model.getTitle());
               Log.d("while","sending"+model.getTitle());
               intent.putExtra("Body",model.getBody());
               mcontext.startActivity(intent)  ;

           }
       });






    }

    private void deleteItem(int postlistId) {
        final ProgressDialog dialog=new ProgressDialog(mcontext);
        dialog.setMessage("deleting");
        dialog.setCancelable(false);
        dialog.show();

        apiInterface= ApiClient.getClient().create(ApiInterface.class);

        retrofit2.Call<ResponseBody> deleteitem=apiInterface.deletePost(postlistId);
        deleteitem.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(retrofit2.Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body()!=null){
                    dialog.dismiss();
                    Log.d("deleted","item"+response.toString());

                    //apiInterface.getPosts();
                    notifyDataSetChanged();
                }
                else {
                   // dialog.dismiss();
                    Toast.makeText(mcontext, "error ", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(retrofit2.Call<ResponseBody> call, Throwable t) {
                Log.e("Infailure","ondeleteList"+t.getMessage());

            }
        });

    }

    @Override
    public int getItemCount() {
        if(mlist!=null){
           return   mlist.size();
        }
        return 0;
    }





    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView titletxt,contenttxt;
        ImageView editImg,deleteImg;


        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            titletxt=(TextView)itemView.findViewById(R.id.title_txt_content);
            contenttxt=(TextView)itemView.findViewById(R.id.contnt_txt_content);
            editImg =(ImageView)itemView.findViewById(R.id.edit_postImg);
            deleteImg=(ImageView)itemView.findViewById(R.id.delete_postImg);



        }
    }




   /* public void setOnItemclickListener(ItemClickListener itemclickListener){
        itemclickListener=itemClickListener;
    }


    public interface ItemClickListener{
         void onItemClick(View view,int position);
    }
*/
}
